import { Text, Image, View } from 'react-native';

export default function App() {
  return (
    <View style={{ flex: 1 }}>

      <View style={{ backgroundColor: 'cyan', padding: 20 }}>
        <Text style={{ color: 'white', fontSize: 20 }}>
          Kauã Freire
        </Text>
      </View>

      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>

        <Image
          source={require('./assets/kaua-foto.jpeg') }
          style={{ width: 100, height: 100 }}
        />

        <Text style={{ fontSize: 20 }}>Kauã Freire</Text>

        <Text>Técnico em Informática para Internet</Text>

        <Text>Objetivo</Text>
        <Text>Trabalhar na área de tecnologia.</Text>

        <Text>Formação</Text>
        <Text>Técnico em Informática para Internet</Text>

        <Text>Redes Socias</Text>
        <Text>@kau4.lx</Text>

        <Text>Contato</Text>
        <Text>kauafreire@email.com</Text>

      </View>

      <View style={{ padding: 10, backgroundColor: '#eee' }}>
        <Text>Técnico em Informática para Internet</Text>
      </View>

    </View>
  );
}
